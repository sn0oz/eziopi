:mod:`apscheduler.jobstores.base`
=================================

.. automodule:: apscheduler.jobstores.base

API
---

.. autoclass:: BaseJobStore
    :members:
