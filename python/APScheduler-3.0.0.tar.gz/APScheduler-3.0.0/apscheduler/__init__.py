version_info = (3, 0, 0)
version = '3.0.0'
release = '3.0.0'

__version__ = release  # PEP 396
